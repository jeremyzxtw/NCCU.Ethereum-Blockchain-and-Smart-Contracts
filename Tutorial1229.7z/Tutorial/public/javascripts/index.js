function change_color(){
    document.getElementById("p1").style.color = "red";
}